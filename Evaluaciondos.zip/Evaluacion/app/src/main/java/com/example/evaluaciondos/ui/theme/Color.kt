package com.example.evaluaciondos.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0x6200EE)
val Purple700 = Color(0xFFFAFAFA)
val Teal200 = Color(0xFF03DAC5)
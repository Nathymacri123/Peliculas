package com.example.evaluaciondos.nav

import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class AppNav(val route: String) {
    object LoginScreen : AppNav(route = "LoginScreen")
    object Home : AppNav(route = "Home")
    object ListaPeliculas : AppNav(route = "ListaPeliculas")
    object AddScreen : AppNav(route = "AddScreen")
    object InformacionPeli:
        AppNav(route = "InformacionPeli/{foto}/{nombre}/{descripcion}/{url}") {
        fun String.encodeUrl() = URLEncoder.encode(this, StandardCharsets.UTF_8.toString())
        fun new_route(foto : String, nombre : String, descripcion: String, url : String): String {
            return "InformacionPeli/${foto.encodeUrl()}/$nombre/$descripcion/${url.encodeUrl()}"
        } // Fin new_route
    } // Fin InformacionPeli
} // Fin AppNav
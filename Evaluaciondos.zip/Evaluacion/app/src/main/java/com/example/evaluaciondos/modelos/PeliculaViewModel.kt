package com.example.evaluaciondos.modelos

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase

class PeliculaViewModel : ViewModel() {
    private val _peli = mutableStateOf<List<Pelicula>>(emptyList())
    val peliculas: State<List<Pelicula>>
        get() = _peli
    private val query = Firebase.firestore.collection("peliculas")
    init {
        query.addSnapshotListener { value, _ ->
            if (value != null) {
                _peli.value = value.toObjects()
            } //fin If
        } //fin Listener
    } //fin init
} //fin PlantaViewModel
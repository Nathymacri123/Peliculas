package com.example.evaluaciondos.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.evaluaciondos.nav.AppNav

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun InformacionPeli(
    navController: NavController,
    foto: String,
    nombre: String,
    descripcion: String,
    url: String,
) {
    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(15.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Icon(
                    modifier = Modifier.clickable { navController.navigate(AppNav.ListaPeliculas.route) },
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = null,
                    tint = Color.Black
                )
                Text(text = "DETAILS")
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = null,
                    tint = Color.Black
                )
            } // Fin Row
        }, // Fin topBar
    ) {
        BodyInformation(navController, foto, nombre, descripcion, url)
    } // Fin BodyInformation
} // Fin InformacionPeli

@Composable
fun BodyInformation(
    navController: NavController,
    foto: String,
    nombre: String,
    descripcion: String,
    url: String,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(15.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = rememberAsyncImagePainter(foto),
            contentDescription = "Imagen",
            contentScale = ContentScale.FillWidth
        )
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = nombre,
            style = MaterialTheme.typography.h4
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = descripcion
        )
        val uriHandler = LocalUriHandler.current
        Text(text = "From Wikipedia", modifier = Modifier.clickable {
            uriHandler.openUri(url)
        } // Fin Clickable
        ) //  Fin Text
    } // Fin Column
} // Fin BodyInformation

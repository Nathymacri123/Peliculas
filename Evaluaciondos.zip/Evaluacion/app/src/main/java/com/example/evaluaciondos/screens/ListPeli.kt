package com.example.evaluaciondos.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PermMedia
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.evaluaciondos.modelos.Pelicula
import com.example.evaluaciondos.modelos.PeliculaViewModel
import com.example.evaluaciondos.nav.AppNav
import com.example.evaluaciondos.ui.theme.Shapes

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun ListaPeliculas(navController: NavController, viewModel: PeliculaViewModel) {
    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, color = Color.Black)
            ) {
                Text(
                    text = "MOVIEMANIA",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    fontSize = 34.sp,
                    color = Color.Black
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(AppNav.Home.route) }
                    ) {
                        Icon(
                            imageVector = Icons.Default.List,
                            contentDescription = null,
                            tint = Color.Black
                        )
                    } // Fin Column MY MOVIES
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(AppNav.ListaPeliculas.route) }
                    ) {
                        Icon(
                            imageVector = Icons.Default.PermMedia,
                            contentDescription = null,
                            tint = Color.Black,
                        )

                    } // Fin Column MOVIES LIST
                } // Fin Row
            } // Fin Column Principal
        } // Fin topBar
    ) // Fin Scaffold
    {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Column {
                LazyColumn() {
                    items(viewModel.peliculas.value) { pelicula ->
                        PeliculaCard(pelicula, navController)
                    } // Fin Items
                } // Fin LazyColumn
            } // Fin Column-Box
        } // Fin Box
    } //Fin Scaffold
} // Fin ListaPeliculas

@Composable
fun PeliculaCard(pelicula: Pelicula, navController: NavController) {
    Card(
        modifier = Modifier
            .padding(all = 16.dp)
            .background(Color.Black)
            .fillMaxSize()
            .border(1.dp, color = Color.Black, Shapes.small)
            .clickable {
                navController.navigate(
                    AppNav.InformacionPeli.new_route(
                        pelicula.foto,
                        pelicula.nombre,
                        pelicula.descripcion,
                        pelicula.url
                    )
                )
            } // Fin clickable
    ) //Fin Card
    {
        Column(
            modifier = Modifier
                .fillMaxWidth(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = rememberAsyncImagePainter(pelicula.foto),
                contentDescription = "",
                modifier = Modifier.size(200.dp)
            ) // Fin Image
            Text(
                text = pelicula.nombre,
                color = Color.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(4.dp),
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
            )
        } // Fin Column
    } // Fin Card
} // Fin PeliculaCard